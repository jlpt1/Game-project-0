﻿
using var game = new SpriteExample.SpriteExampleGame();
game.Run();
